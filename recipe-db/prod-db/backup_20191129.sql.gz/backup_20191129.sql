--
-- PostgreSQL database dump
--

-- Dumped from database version 10.4
-- Dumped by pg_dump version 10.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: _v; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA _v;


ALTER SCHEMA _v OWNER TO postgres;

--
-- Name: SCHEMA _v; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA _v IS 'Schema for versioning data and functionality.';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: assert_patch_is_applied(text); Type: FUNCTION; Schema: _v; Owner: postgres
--

CREATE FUNCTION _v.assert_patch_is_applied(in_patch_name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    t_text TEXT;
BEGIN
    SELECT patch_name INTO t_text FROM _v.patches WHERE patch_name = in_patch_name;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Patch % is not applied!', in_patch_name;
    END IF;
    RETURN format('Patch %s is applied.', in_patch_name);
END;
$$;


ALTER FUNCTION _v.assert_patch_is_applied(in_patch_name text) OWNER TO postgres;

--
-- Name: FUNCTION assert_patch_is_applied(in_patch_name text); Type: COMMENT; Schema: _v; Owner: postgres
--

COMMENT ON FUNCTION _v.assert_patch_is_applied(in_patch_name text) IS 'Function that can be used to make sure that patch has been applied.';


--
-- Name: assert_user_is_not_superuser(); Type: FUNCTION; Schema: _v; Owner: postgres
--

CREATE FUNCTION _v.assert_user_is_not_superuser() RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_super bool;
BEGIN
    SELECT usesuper INTO v_super FROM pg_user WHERE usename = current_user;
    IF v_super THEN
        RAISE EXCEPTION 'Current user is superuser - cannot continue.';
    END IF;
    RETURN 'assert_user_is_not_superuser: OK';
END;
$$;


ALTER FUNCTION _v.assert_user_is_not_superuser() OWNER TO postgres;

--
-- Name: FUNCTION assert_user_is_not_superuser(); Type: COMMENT; Schema: _v; Owner: postgres
--

COMMENT ON FUNCTION _v.assert_user_is_not_superuser() IS 'Function that can be used to make sure that patch is being applied using normal (not superuser) account.';


--
-- Name: assert_user_is_one_of(text[]); Type: FUNCTION; Schema: _v; Owner: postgres
--

CREATE FUNCTION _v.assert_user_is_one_of(VARIADIC p_acceptable_users text[]) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
BEGIN
    IF current_user = any( p_acceptable_users ) THEN
        RETURN 'assert_user_is_one_of: OK';
    END IF;
    RAISE EXCEPTION 'User is not one of: % - cannot continue.', p_acceptable_users;
END;
$$;


ALTER FUNCTION _v.assert_user_is_one_of(VARIADIC p_acceptable_users text[]) OWNER TO postgres;

--
-- Name: FUNCTION assert_user_is_one_of(VARIADIC p_acceptable_users text[]); Type: COMMENT; Schema: _v; Owner: postgres
--

COMMENT ON FUNCTION _v.assert_user_is_one_of(VARIADIC p_acceptable_users text[]) IS 'Function that can be used to make sure that patch is being applied by one of defined users.';


--
-- Name: assert_user_is_superuser(); Type: FUNCTION; Schema: _v; Owner: postgres
--

CREATE FUNCTION _v.assert_user_is_superuser() RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_super bool;
BEGIN
    SELECT usesuper INTO v_super FROM pg_user WHERE usename = current_user;
    IF v_super THEN
        RETURN 'assert_user_is_superuser: OK';
    END IF;
    RAISE EXCEPTION 'Current user is not superuser - cannot continue.';
END;
$$;


ALTER FUNCTION _v.assert_user_is_superuser() OWNER TO postgres;

--
-- Name: FUNCTION assert_user_is_superuser(); Type: COMMENT; Schema: _v; Owner: postgres
--

COMMENT ON FUNCTION _v.assert_user_is_superuser() IS 'Function that can be used to make sure that patch is being applied using superuser account.';


--
-- Name: register_patch(text); Type: FUNCTION; Schema: _v; Owner: postgres
--

CREATE FUNCTION _v.register_patch(text) RETURNS SETOF integer
    LANGUAGE sql
    AS $_$
    SELECT _v.register_patch( $1, NULL, NULL );
$_$;


ALTER FUNCTION _v.register_patch(text) OWNER TO postgres;

--
-- Name: FUNCTION register_patch(text); Type: COMMENT; Schema: _v; Owner: postgres
--

COMMENT ON FUNCTION _v.register_patch(text) IS 'Wrapper to allow registration of patches without requirements and conflicts.';


--
-- Name: register_patch(text, text[]); Type: FUNCTION; Schema: _v; Owner: postgres
--

CREATE FUNCTION _v.register_patch(text, text[]) RETURNS SETOF integer
    LANGUAGE sql
    AS $_$
    SELECT _v.register_patch( $1, $2, NULL );
$_$;


ALTER FUNCTION _v.register_patch(text, text[]) OWNER TO postgres;

--
-- Name: FUNCTION register_patch(text, text[]); Type: COMMENT; Schema: _v; Owner: postgres
--

COMMENT ON FUNCTION _v.register_patch(text, text[]) IS 'Wrapper to allow registration of patches without conflicts.';


--
-- Name: register_patch(text, text[], text[]); Type: FUNCTION; Schema: _v; Owner: postgres
--

CREATE FUNCTION _v.register_patch(in_patch_name text, in_requirements text[], in_conflicts text[], OUT versioning integer) RETURNS SETOF integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    t_text   TEXT;
    t_text_a TEXT[];
    i INT4;
BEGIN
    -- Thanks to this we know only one patch will be applied at a time
    LOCK TABLE _v.patches IN EXCLUSIVE MODE;

    SELECT patch_name INTO t_text FROM _v.patches WHERE patch_name = in_patch_name;
    IF FOUND THEN
        RAISE EXCEPTION 'Patch % is already applied!', in_patch_name;
    END IF;

    t_text_a := ARRAY( SELECT patch_name FROM _v.patches WHERE patch_name = any( in_conflicts ) );
    IF array_upper( t_text_a, 1 ) IS NOT NULL THEN
        RAISE EXCEPTION 'Versioning patches conflict. Conflicting patche(s) installed: %.', array_to_string( t_text_a, ', ' );
    END IF;

    IF array_upper( in_requirements, 1 ) IS NOT NULL THEN
        t_text_a := '{}';
        FOR i IN array_lower( in_requirements, 1 ) .. array_upper( in_requirements, 1 ) LOOP
            SELECT patch_name INTO t_text FROM _v.patches WHERE patch_name = in_requirements[i];
            IF NOT FOUND THEN
                t_text_a := t_text_a || in_requirements[i];
            END IF;
        END LOOP;
        IF array_upper( t_text_a, 1 ) IS NOT NULL THEN
            RAISE EXCEPTION 'Missing prerequisite(s): %.', array_to_string( t_text_a, ', ' );
        END IF;
    END IF;

    INSERT INTO _v.patches (patch_name, applied_tsz, applied_by, requires, conflicts ) VALUES ( in_patch_name, now(), current_user, coalesce( in_requirements, '{}' ), coalesce( in_conflicts, '{}' ) );
    RETURN;
END;
$$;


ALTER FUNCTION _v.register_patch(in_patch_name text, in_requirements text[], in_conflicts text[], OUT versioning integer) OWNER TO postgres;

--
-- Name: FUNCTION register_patch(in_patch_name text, in_requirements text[], in_conflicts text[], OUT versioning integer); Type: COMMENT; Schema: _v; Owner: postgres
--

COMMENT ON FUNCTION _v.register_patch(in_patch_name text, in_requirements text[], in_conflicts text[], OUT versioning integer) IS 'Function to register patches in database. Raises exception if there are conflicts, prerequisites are not installed or the migration has already been installed.';


--
-- Name: unregister_patch(text); Type: FUNCTION; Schema: _v; Owner: postgres
--

CREATE FUNCTION _v.unregister_patch(in_patch_name text, OUT versioning integer) RETURNS SETOF integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    i        INT4;
    t_text_a TEXT[];
BEGIN
    -- Thanks to this we know only one patch will be applied at a time
    LOCK TABLE _v.patches IN EXCLUSIVE MODE;

    t_text_a := ARRAY( SELECT patch_name FROM _v.patches WHERE in_patch_name = ANY( requires ) );
    IF array_upper( t_text_a, 1 ) IS NOT NULL THEN
        RAISE EXCEPTION 'Cannot uninstall %, as it is required by: %.', in_patch_name, array_to_string( t_text_a, ', ' );
    END IF;

    DELETE FROM _v.patches WHERE patch_name = in_patch_name;
    GET DIAGNOSTICS i = ROW_COUNT;
    IF i < 1 THEN
        RAISE EXCEPTION 'Patch % is not installed, so it can''t be uninstalled!', in_patch_name;
    END IF;

    RETURN;
END;
$$;


ALTER FUNCTION _v.unregister_patch(in_patch_name text, OUT versioning integer) OWNER TO postgres;

--
-- Name: FUNCTION unregister_patch(in_patch_name text, OUT versioning integer); Type: COMMENT; Schema: _v; Owner: postgres
--

COMMENT ON FUNCTION _v.unregister_patch(in_patch_name text, OUT versioning integer) IS 'Function to unregister patches in database. Dies if the patch is not registered, or if unregistering it would break dependencies.';


--
-- Name: adduser(character varying, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.adduser(in_username character varying, in_password text) RETURNS integer
    LANGUAGE sql
    AS $$
	INSERT INTO Users (username, password) VALUES (in_username, in_password) RETURNING id;
$$;


ALTER FUNCTION public.adduser(in_username character varying, in_password text) OWNER TO postgres;

--
-- Name: addusershare(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.addusershare(in_fromid integer, in_toid integer) RETURNS void
    LANGUAGE sql
    AS $$
	INSERT INTO ShareRecipes (fromUserId, toUserId) VALUES (in_fromId, in_toId)
$$;


ALTER FUNCTION public.addusershare(in_fromid integer, in_toid integer) OWNER TO postgres;

--
-- Name: deleterecipes(integer, uuid[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.deleterecipes(in_userid integer, in_ids uuid[]) RETURNS void
    LANGUAGE sql
    AS $$
	DELETE FROM Recipes WHERE userId = in_userId AND id = ANY (in_ids)
$$;


ALTER FUNCTION public.deleterecipes(in_userid integer, in_ids uuid[]) OWNER TO postgres;

--
-- Name: deleteuser(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.deleteuser(in_id integer) RETURNS void
    LANGUAGE sql
    AS $$
	DELETE FROM Users WHERE id = in_id 
$$;


ALTER FUNCTION public.deleteuser(in_id integer) OWNER TO postgres;

--
-- Name: deleteusershare(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.deleteusershare(in_fromid integer, in_toid integer) RETURNS void
    LANGUAGE sql
    AS $$
	DELETE FROM ShareRecipes WHERE fromUserId = in_fromId AND toUserId = in_toId
$$;


ALTER FUNCTION public.deleteusershare(in_fromid integer, in_toid integer) OWNER TO postgres;

--
-- Name: getallrecipes(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getallrecipes(in_userid integer) RETURNS TABLE(id uuid, recipe jsonb, createdtime timestamp without time zone, updatedtime timestamp without time zone, userid integer, username character varying)
    LANGUAGE sql
    AS $$
	WITH userRecipes AS (
		SELECT id, userId, recipe, createdTime, updatedTime FROM Recipes r
		WHERE userId = in_userId
		UNION
		SELECT r.id, r.userId, r.recipe, r.createdTime, r.updatedTime FROM Recipes r
		JOIN ShareRecipes sr ON sr.fromUserId = r.userid
		WHERE sr.toUserId = in_userId
	)
	SELECT ur.id, ur.recipe, ur.createdTime, ur.updatedTime, u.id, u.username  FROM userRecipes ur
	JOIN Users u ON u.id = ur.userId
	ORDER BY recipe->'title'
$$;


ALTER FUNCTION public.getallrecipes(in_userid integer) OWNER TO postgres;

--
-- Name: getrecipe(integer, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getrecipe(in_userid integer, in_id uuid) RETURNS TABLE(id uuid, recipe jsonb, createdtime timestamp without time zone, updatedtime timestamp without time zone, userid integer, username character varying)
    LANGUAGE sql
    AS $$
	SELECT r.id, r.recipe, r.createdTime, r.updatedTime, u.id, u.username FROM Recipes r
	JOIN Users u ON r.userId = u.id
	WHERE r.userId = in_userId AND r.id = in_id
$$;


ALTER FUNCTION public.getrecipe(in_userid integer, in_id uuid) OWNER TO postgres;

--
-- Name: getuser(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getuser(in_username character varying) RETURNS TABLE(id integer, username character varying, password text)
    LANGUAGE sql
    AS $$
	SELECT id, username, password FROM Users WHERE username = in_username
$$;


ALTER FUNCTION public.getuser(in_username character varying) OWNER TO postgres;

--
-- Name: getusershare(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getusershare(in_id integer) RETURNS TABLE(id integer, username character varying)
    LANGUAGE sql
    AS $$
	SELECT tu.id, tu.username 
	FROM Users fu
	JOIN ShareRecipes sr ON sr.fromUserId = fu.id
	JOIN Users tu ON sr.toUserId = tu.id
	WHERE fu.id = in_id
$$;


ALTER FUNCTION public.getusershare(in_id integer) OWNER TO postgres;

--
-- Name: insertorupdaterecipe(integer, uuid, jsonb); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insertorupdaterecipe(in_userid integer, in_id uuid, in_recipe jsonb) RETURNS void
    LANGUAGE sql
    AS $$
	INSERT INTO Recipes (id, userId, recipe) VALUES (in_id, in_userId, in_recipe)
	ON CONFLICT (id) DO UPDATE SET recipe = EXCLUDED.recipe, updatedTime = CURRENT_TIMESTAMP
$$;


ALTER FUNCTION public.insertorupdaterecipe(in_userid integer, in_id uuid, in_recipe jsonb) OWNER TO postgres;

--
-- Name: updateuser(integer, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.updateuser(in_id integer, in_password text) RETURNS void
    LANGUAGE sql
    AS $$
	UPDATE Users SET password = in_password WHERE id = in_id
$$;


ALTER FUNCTION public.updateuser(in_id integer, in_password text) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: patches; Type: TABLE; Schema: _v; Owner: postgres
--

CREATE TABLE _v.patches (
    patch_name text NOT NULL,
    applied_tsz timestamp with time zone DEFAULT now() NOT NULL,
    applied_by text NOT NULL,
    requires text[],
    conflicts text[]
);


ALTER TABLE _v.patches OWNER TO postgres;

--
-- Name: TABLE patches; Type: COMMENT; Schema: _v; Owner: postgres
--

COMMENT ON TABLE _v.patches IS 'Contains information about what patches are currently applied on database.';


--
-- Name: COLUMN patches.patch_name; Type: COMMENT; Schema: _v; Owner: postgres
--

COMMENT ON COLUMN _v.patches.patch_name IS 'Name of patch, has to be unique for every patch.';


--
-- Name: COLUMN patches.applied_tsz; Type: COMMENT; Schema: _v; Owner: postgres
--

COMMENT ON COLUMN _v.patches.applied_tsz IS 'When the patch was applied.';


--
-- Name: COLUMN patches.applied_by; Type: COMMENT; Schema: _v; Owner: postgres
--

COMMENT ON COLUMN _v.patches.applied_by IS 'Who applied this patch (PostgreSQL username)';


--
-- Name: COLUMN patches.requires; Type: COMMENT; Schema: _v; Owner: postgres
--

COMMENT ON COLUMN _v.patches.requires IS 'List of patches that are required for given patch.';


--
-- Name: COLUMN patches.conflicts; Type: COMMENT; Schema: _v; Owner: postgres
--

COMMENT ON COLUMN _v.patches.conflicts IS 'List of patches that conflict with given patch.';


--
-- Name: recipes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recipes (
    id uuid NOT NULL,
    userid integer,
    recipe jsonb,
    createdtime timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updatedtime timestamp without time zone
);


ALTER TABLE public.recipes OWNER TO postgres;

--
-- Name: sharerecipes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sharerecipes (
    id integer NOT NULL,
    fromuserid integer,
    touserid integer
);


ALTER TABLE public.sharerecipes OWNER TO postgres;

--
-- Name: sharerecipes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sharerecipes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sharerecipes_id_seq OWNER TO postgres;

--
-- Name: sharerecipes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sharerecipes_id_seq OWNED BY public.sharerecipes.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(256),
    password text
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: sharerecipes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sharerecipes ALTER COLUMN id SET DEFAULT nextval('public.sharerecipes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: patches; Type: TABLE DATA; Schema: _v; Owner: postgres
--

COPY _v.patches (patch_name, applied_tsz, applied_by, requires, conflicts) FROM stdin;
000-createUsers	2018-06-03 20:11:41.732913+00	postgres	{}	{}
000-createRecipes	2018-06-03 20:11:41.915454+00	postgres	{000-createUsers}	{}
001-shareRecipes	2019-11-28 16:57:39.303754+00	postgres	{000-createUsers}	{}
001-alterRecipeSchema	2019-11-28 16:57:39.368351+00	postgres	{000-createRecipes}	{}
\.


--
-- Data for Name: recipes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recipes (id, userid, recipe, createdtime, updatedtime) FROM stdin;
915e8957-08a2-43ae-b94d-d185b421e0f0	1	{"title": "Quiche", "method": "Thoroughly sauté vegetables. Place filling in blind-baked pie shell. Add a pinch of salt and pepper to egg mixture and pour it into the shell. Sprinkle cheese on top.\\r\\n\\r\\nBake at 350°F for 30 to 40 minutes, or until custard is set or a knife inserted in the center comes out clean.\\r\\n", "sources": [], "ingredients": [{"name": "2 cups filling", "quantity": "1 1/2 to"}, {"name": "eggs plus enough half-and-half to equal 3 cups", "quantity": "6 large"}, {"name": "Cheese"}]}	2018-06-09 16:53:00.165	2018-06-09 16:53:00.165
302ce1bf-6ef7-4dee-adff-68059970e815	1	{"title": "Brats", "method": "", "sources": [], "ingredients": []}	2012-10-14 16:59:30	\N
741919f2-b33c-4764-930a-3a58378eed60	1	{"title": "Potato Rösti", "method": "1. Scrub, optionally peel, and grate potatoes. Heat a skillet over medium heat.\\r\\n2. Toss potatoes with salt and pepper. Put ~2 tablespoons fat in skillet and heat. Put taters in skillet, and then press and shape them. Turn heat to medium-high and cook (shaking occasionally) for 6 to 8 minutes.\\r\\n3. Slide taters onto a plate. Use a second plate to flip. Add some more fat, and then slide taters back in. Cook until second side is browned, 5 to 10 minutes.", "sources": [], "ingredients": [{"name": "Potatoes"}]}	2018-08-31 22:58:20.67	2018-08-31 22:58:20.67
ba075c6f-2489-4ecb-90ca-5020be0ddde2	1	{"title": "Pasta with Red Sauce", "method": "", "sources": [], "ingredients": []}	2012-10-14 16:58:40	\N
fcab086a-bbf7-4096-9234-42eece513956	1	{"title": "Roasted Potatoes", "method": "1. Heat oven to 400°F.\\r\\n2. Scrub and chunk potatoes.\\r\\n3. Toss potatoes in pan with fat, salt, and pepper.\\r\\n4. Roast 20 minutes. Check and toss. Roast another 20-40 minutes until done. Check and toss every 10 minutes.", "sources": [], "ingredients": [{"name": "Potatoes"}, {"name": "Fat"}]}	2018-09-07 23:11:50.003	2018-09-07 23:11:50.003
4858b5ba-60e4-4c48-b56f-79f7c6d91f2e	1	{"title": "Turkey Burgers", "method": "#### Other Stuff\\r\\n\\r\\n* Buns\\r\\n* Mayo\\r\\n* Lettuce\\r\\n* Tomato\\r\\n\\r\\n#### Sides\\r\\n\\r\\n* Sweet Potatoes\\r\\n* Potatoes\\r\\n* Chips\\r\\n", "sources": [], "ingredients": [{"name": "Ground Turkey"}, {"name": "Poblano Pepper"}, {"name": "Garlic"}, {"name": "Snoino"}, {"name": "Cumin"}, {"name": "Bread Crumbs"}, {"name": "Egg"}, {"name": "Cilantro"}]}	2018-06-09 19:22:44.155	2018-06-09 19:22:44.155
1b81d7d6-47d8-445a-8d8a-382500409286	1	{"title": "Balsalmic Chicken Wraps", "method": "Marinate chicken in balsalmic, olive oil, garlic, salt and pepper.\\r\\n\\r\\nSauté onion and shredded carrot. Add mushrooms. Add red pepper. Add spinach. Splash some cider vinegar.\\r\\n\\r\\nPan fry chicken.\\r\\n\\r\\nServe in flour tortillas with shredded cheese.", "sources": [], "ingredients": [{"name": "Chicken"}, {"name": "Garlic"}, {"name": "Balsalmic vinegar"}, {"name": "Onion"}, {"name": "Carrot"}, {"name": "Red Pepper"}, {"name": "Mushrooms"}, {"name": "Spinach"}, {"name": "Comte cheese"}, {"name": "Tortillas"}]}	2014-02-14 01:01:25	2014-02-14 01:04:56
680140fb-2042-4d26-9369-5aa11c97114c	1	{"title": "Burrito Bowl", "method": "Put corn in hot pan with oil and onions until it begins to brown. Add bell pepper, beans, garlic, cumin, and oregano.\\r\\n\\r\\nMarinate chicken in lime, cumin, paprika, salt, pepper, and olive oil. Pan fry (15-20 minutes).\\r\\n", "sources": [], "ingredients": [{"name": "Chicken thighs (boneless, skinless), or Pulled Pork"}, {"name": "Corn"}, {"name": "Onion"}, {"name": "Black Beans"}, {"name": "Bell Pepper"}, {"name": "Garlic"}, {"name": "Lettuce"}, {"name": "Avocado"}, {"name": "Salsa"}, {"name": "Brown Rice"}, {"name": "Cheese"}]}	2018-09-20 22:51:11.389	2018-09-20 22:51:11.389
a53427f9-c735-4873-9f9f-183603c1cd0a	1	{"title": "Lamb Burgers", "method": "", "sources": [], "ingredients": []}	2012-10-17 19:06:30	\N
3fa1f9ae-58ce-46be-9899-fb69b860f33d	1	{"title": "Tacos (Mushroom Chard)", "method": "", "sources": ["http://www.wholefoodsmarket.com/recipes/3060"], "ingredients": []}	2012-10-14 17:09:35	2012-11-04 16:33:16
da2357aa-d22f-494a-a54f-1714d83c1af0	1	{"title": "Pork Chops", "method": "", "sources": [], "ingredients": []}	2012-12-13 21:41:28	\N
e5a1b18b-1187-4a82-b9a1-8372a42d0093	1	{"title": "Sandwiches", "method": "", "sources": [], "ingredients": []}	2012-11-08 14:22:10	2012-11-08 14:22:26
c5d2720e-ea66-4e8a-9a99-f2e6e2656567	1	{"title": "Sausage Kale Soup", "method": "Cut carrots into dice. Potatoes in to 1/4ths, 1/6ths, or 1/8ths depending on size.\\r\\n\\r\\nSaute a mirepoix of carrots, celery, and snoino. Add stock, thyme, bay leaf, and taters. Brown sausage and add to soup. When potatoes are nearly done, add coarsely chopped kale and crushed garlic.\\r\\n\\r\\nWhen soup is ready, add freshly grated parmesan cheese.\\r\\n\\r\\nServe with crusty bread.", "sources": [], "ingredients": [{"name": "Mild Italian Sausage (1/2 - 2/3 Lb)"}, {"name": "Potatoes (6)"}, {"name": "Carrots (2)"}, {"name": "Celery (2)"}, {"name": "Kale (1 bunch)"}, {"name": "Snoino"}, {"name": "Stock (4 c.)"}, {"name": "Thyme"}, {"name": "Bay Leaf"}, {"name": "Parmesan Cheese"}, {"name": "Cider Vinegar"}, {"name": "Garlic"}]}	2012-12-09 17:05:28	2012-12-13 21:45:42
d5e828eb-86f5-494f-842c-0c575ed3fdf5	1	{"title": "Shredded Beef Sandwiches", "method": "", "sources": [], "ingredients": []}	2013-08-17 16:09:43	\N
e877b3a0-d98c-47da-8d77-e7bb122a3a41	1	{"title": "Chicken Burritos", "method": "Cook four boneless skinless chicken thighs with one can tomatoes (drained) and chili/taco seasonings in crock pot for 4-5 hours.\\r\\n\\r\\nSauté onions and then add drained black beans and red peppers.\\r\\n\\r\\nEat with tortillas, brown short grain rice, avocado, and cheese.", "sources": [], "ingredients": [{"name": "Boneless, Skinless Chicken Thighs", "quantity": "4"}, {"name": "Tomatoes"}, {"name": "Snoino"}, {"name": "Black Beans"}, {"name": "Red Bell Pepper"}, {"name": "Tortillas"}, {"name": "Avocado"}, {"name": "Cheese"}]}	2018-06-09 18:53:21.672	2018-06-09 18:53:21.672
74fe0c93-dafe-4135-9522-dfe1603f1188	1	{"title": "Salmon in Foil", "method": "Bake in 375°F - 400°F oven for 15-20 minutes until internal temperature is 125°F - 145°F.\\r\\n\\r\\n", "sources": ["https://damndelicious.net/2016/05/23/garlic-butter-salmon-foil/", "https://www.foodnetwork.com/recipes/giada-de-laurentiis/salmon-baked-in-foil-recipe-1914818", "https://www.allrecipes.com/recipe/263217/baked-salmon-in-foil/", "https://therecipecritic.com/butter-garlic-herb-salmon-foil-packets/"], "ingredients": [{"name": "Salmon"}, {"name": "Flavors"}]}	2018-08-22 23:56:03.086	2018-08-22 23:56:03.086
7964ea4e-eb68-45ef-9d84-beda38bb9b72	1	{"title": "Chicken and Rice with Summer Squash", "method": "", "sources": [], "ingredients": [{"name": "Stock"}, {"name": "Snoino"}, {"name": "Arborio Rice"}, {"name": "Chicken"}, {"name": "Garlic"}, {"name": "Bell Pepper"}, {"name": "Mushrooms"}, {"name": "Summer squash"}, {"name": "Dash of smoked paprika"}, {"name": "Splash of sherry vinegar"}]}	2012-10-14 17:00:56	2014-07-31 00:16:50
c98f5c97-2d5a-429f-b568-1fcd66b9822a	1	{"title": "Hamburgers", "method": "", "sources": [], "ingredients": []}	2012-10-14 16:59:21	\N
7cc65f7b-411c-416b-b21b-e32f7a4e66c2	1	{"title": "Jerk Chicken", "method": "Make marinade by blending lime juice, rum, olive oil, jerk seasoning, and habanero pepper in a blender. Marinate chicken for 30-60 minutes. Grill chicken.\\r\\n\\r\\nMake curry rice by combining cooked jasmine rice with butter, whine, onions, and curry powder.\\r\\n\\r\\nBoil, steam, or roast the broccoli.\\r\\n\\r\\n#### Jerk Seasoning\\r\\n\\r\\nIngredient list from Penzeys Spices Jerk Chicken & Fish seasoning:\\r\\n\\r\\n* ginger, ancho, brown sugar, garlic, paprika, allspice, lemongrass, thyme, nutmeg, black pepper, cumin, cayenne, and jalapeño\\r\\n\\r\\n\\r\\n\\r\\n", "sources": [], "ingredients": [{"name": "Chicken Thighs or Legs"}, {"name": "Lime Juice"}, {"name": "Rum (optional)"}, {"name": "Olive Oil"}, {"name": "Jerk Seasoning"}, {"name": "Habanero Pepper"}, {"name": "Jasmine Rice"}, {"name": "Sweet Yellow Curry Powder"}, {"name": "White wine"}, {"name": "Snoino"}, {"name": "Broccoli"}]}	2018-06-09 19:07:01.478	2018-06-09 19:07:01.478
f6b794ba-996a-4429-9b4c-d9b2b7b2ecdd	1	{"title": "Tuna Melt", "method": "", "sources": [], "ingredients": [{"name": "Tuna"}, {"name": "Mayo"}, {"name": "Celery"}, {"name": "Cholula"}, {"name": "Buns or English Muffins"}, {"name": "Cheese"}]}	2014-03-23 15:37:55	2014-03-23 15:40:03
8e995465-cbb4-4da3-bd80-2edcd638e820	1	{"title": "Moroccan Lentil Soup", "method": "1. In large pot saute; the onions, garlic, and ginger in a little olive oil for about 5 minutes.\\r\\n1. Add the water, lentils, chick peas, white kidney beans, diced tomatoes, carrots, celery, garam masala, cardamom, cayenne pepper and cumin. Bring to a boil for a few minutes then simmer for 1 to 1 1/2 hours or longer, until the lentils are soft.\\r\\n1. Puree half the soup in a food processor or blender. Return the pureed soup to the pot, stir and enjoy!\\r\\n", "sources": ["http://allrecipes.com/recipe/moroccan-lentil-soup/"], "ingredients": [{"name": "onions, chopped", "quantity": "2"}, {"name": "garlic, minced", "quantity": "2 cloves"}, {"name": "grated fresh ginger", "quantity": "1 teaspoon"}, {"name": "water", "quantity": "6 cups"}, {"name": "red lentils", "quantity": "1 cup"}, {"name": "(15 ounce) can garbanzo beans, drained", "quantity": "1"}, {"name": "(19 ounce) can cannellini beans", "quantity": "1"}, {"name": "(14.5 ounce) can diced tomatoes", "quantity": "1"}, {"name": "diced carrots", "quantity": "1/2 cup"}, {"name": "chopped celery", "quantity": "1/2 cup"}, {"name": "garam masala", "quantity": "1 teaspoon"}, {"name": "ground cardamom", "quantity": "1 1/2 teaspoons"}, {"name": "ground cayenne pepper", "quantity": "1/2 teaspoon"}, {"name": "ground cumin", "quantity": "1/2 teaspoon"}, {"name": "olive oil", "quantity": "1 tablespoon"}]}	2018-06-09 19:08:59.051	2018-06-09 19:08:59.051
41346f12-2f3b-4052-85e1-52f0aac5bfde	1	{"title": "Beans and Rice", "method": "Soak beans. Cook beans in water with bay leaf, thyme, smoked paprika, a little cumin, and plenty of black pepper. Beans will take up to an hour.\\r\\n\\r\\nWhile beans are cooking, cook rice like a pilaf with everything else (including some thyme) except the bacon and greens.\\r\\n\\r\\nAs soon as the rice is cooking, start the bacon. Chop the greens. When the bacon has rendered some of its fat, remove from pan and discard the fat. Return the bacon to the pan with the greens and some white wine. Cover.\\r\\n\\r\\nWhen all is done, combine in pan with the rice.", "sources": [], "ingredients": [{"name": "Beans (reddish)"}, {"name": "Bay leaf"}, {"name": "Cumin"}, {"name": "Paprika"}, {"name": "Thyme"}, {"name": "Rice"}, {"name": "Tomatoes"}, {"name": "Onion"}, {"name": "Bell pepper"}, {"name": "Garlic"}, {"name": "Stock"}, {"name": "Greens"}, {"name": "Bacon"}]}	2018-06-23 22:05:05.44	2018-06-23 22:05:05.44
26efe0fb-2d5a-4ba6-9af1-cef9117ce603	1	{"title": "Pot Roast", "method": "First and foremost, choose a nicely marbled piece of meat. This will enhance the flavor of your pot roast like nothing else. Generously salt and pepper your chuck roast.\\r\\n\\r\\nHeat a large pot or Dutch oven over medium-high heat. Then add 2 to 3 tablespoons of olive oil (or you can do a butter/olive oil split). \\r\\n\\r\\nCut two onions in half and cut 6 to 8 carrots into 2-inch slices (you can peel them, but you don’t have to). When the oil in the pot is very hot (but not smoking), add in the halved onions, browning them on one side and then the other. Remove the onions to a plate. \\r\\n\\r\\nThrow the carrots into the same very hot pan and toss them around a bit until slightly browned, about a minute or so.\\r\\n\\r\\nIf needed, add a bit more olive oil to the very hot pan. Place the meat in the pan and sear it for about a minute on all sides until it is nice and brown all over. Remove the roast to a plate. \\r\\n\\r\\nWith the burner still on high, use either red wine or beef broth (about 1 cup) to deglaze the pan, scraping the bottom with a whisk to get all of that wonderful flavor up. \\r\\n\\r\\nWhen the bottom of the pan is sufficiently deglazed, place the roast back into the pan and add enough beef stock to cover the meat halfway (about 2 to 3 cups). Add in the onion and the carrots, as well as 3 or 4 sprigs of fresh rosemary and about 3 sprigs of fresh thyme.\\r\\n\\r\\nPut the lid on, then roast in a 275°F oven for 3 hours (for a 3-pound roast). For a 4 to 5-pound roast, plan on 4 hours.\\r\\n", "sources": ["http://thepioneerwoman.com/cooking/2011/09/2008_the_year_of_the_pot_roast/"], "ingredients": [{"name": "Chuck Roast"}, {"name": "Snoino"}, {"name": "Carrots"}, {"name": "red wine", "quantity": "1 cup"}, {"name": "beef stock", "quantity": "2-3 cups"}, {"name": "Fresh Thyme"}, {"name": "Fresh Rosemary"}]}	2018-06-09 19:13:02.628	2018-06-09 19:13:02.628
24017bdf-4140-47ba-9063-19e0559bde10	1	{"title": "Roasted Chicken Parts", "method": "1. Heat oven to 450°F. Put oil or butter in a roasting pan and put in oven until oil is warm or butter has melted. Turn the chicken in the fat leaving it skin side up. Sprinkle with salt and pepper.\\r\\n2. Roast 15 minutes. Add one-quarter of herbs, turn chicken, then add another quarter of herbs.\\r\\n3. Roast 10 minutes. Turn chicken back skin side up. Add another quarter of herbs.\\r\\n4. Roast until chicken is done (5-15 minutes).\\r\\n\\r\\n\\r\\n", "sources": ["Mark Bittman (How to Cook Everything)"], "ingredients": [{"name": "Chicken"}, {"name": "Herbs (optional)"}]}	2018-09-29 20:35:09.753	2018-09-29 20:35:09.753
38d08de7-2c34-454d-ad6d-b13606d0662a	1	{"title": "Pulled Pork", "method": "1. Cut the pork into 2-3 inch chunks.\\r\\n2. Put meat, rub, and smoke in slow cooker.\\r\\n3. Cook on high to 5 to 6 hours or on low for 10 to 12 hours\\r\\n\\r\\n#### Rub\\r\\n* Paprika\\r\\n* Salt\\r\\n* Black pepper\\r\\n* Garlic\\r\\n* Dry mustard\\r\\n\\r\\n", "sources": ["http://www.publicradio.org/columns/splendid-table/recipes/main_pulledpork.html"], "ingredients": [{"name": "Pork Roast (shoulder, Boston butt, or boneless country-style ribs)"}, {"name": "Dry Rub"}, {"name": "Liquid Smoke"}]}	2018-06-09 19:16:33.833	2018-06-09 19:16:33.833
c5a2d455-f632-4320-9305-75cd336e82a1	1	{"title": "Thai Coconut Chicken Curry", "method": "", "sources": [], "ingredients": [{"name": "Chicken Tenders or Breast"}, {"name": "Carrots"}, {"name": "Red Bell Pepper"}, {"name": "Peas"}, {"name": "Coconut Milk"}, {"name": "Curry Paste"}, {"name": "Soy Sauce"}, {"name": "Basil (Optional)"}, {"name": "Jasmine Rice"}]}	2012-10-14 16:33:24	2012-10-14 16:34:49
885ca805-32b6-447d-a8c1-2604af4c328e	1	{"title": "Split Pea Soup with Lamb Shanks", "method": "Brown lamb shanks in 8 quarts stock pot in 2 tablespoons oil. Remove; add 2 tablespoons butter to stock pot, saute onion, garlic, carrot, celery and potatoes until limp. Add lamb shanks back to pot with remaining ingredients. Cover, bring to boil, reduce to simmer and cook about 2 hours, stirring occasionally, until lamb shanks are tender. Remove shanks from soup, pull meat from bones return to soup. Simmer 30 minutes longer. Remove bay leaf and serve croutons with soup. You may substitute a meaty ham bone for lamb shanks. Do not brown ham and substitute dry sherry for white wine.\\r\\n", "sources": ["http://www.cooks.com/recipe/qk63n3fk/split-pea-soup-with-lamb-shanks.html"], "ingredients": [{"name": "lamb shanks, browned in 2 tbsp. oil (or ham hocks, not browned)", "quantity": "2 lg."}, {"name": "onion, diced", "quantity": "1 med."}, {"name": "garlic, minced", "quantity": "2 cloves"}, {"name": "carrot, diced", "quantity": "1"}, {"name": "celery, diced", "quantity": "1 rib"}, {"name": "baking potato, peeled and diced", "quantity": "1 med."}, {"name": "butter", "quantity": "2 tbsp."}, {"name": "salt", "quantity": "1/2 tsp."}, {"name": "pepper", "quantity": "1/2 tsp."}, {"name": "Several dashes of Tabasco sauce"}, {"name": "thyme", "quantity": "1/2 tsp."}, {"name": "marjoram", "quantity": "1/2 tsp."}, {"name": "leaf", "quantity": "1 bay"}, {"name": "split peas, rinsed and drained", "quantity": "2 c."}, {"name": "chicken broth", "quantity": "6 c."}, {"name": "white wine", "quantity": "1/3 c."}, {"name": "water", "quantity": "3 c."}]}	2018-06-09 19:19:26.322	2018-06-09 19:19:26.322
8a1e2679-39c4-4a81-aad7-a41cd515cd0a	1	{"title": "Sticky Chicken Wings", "method": "In a very large nonstick skillet (or in batches), cook the chicken wings over moderate heat, turning once, until golden, about 8 minutes. Add the ginger, chiles, star anise and cinnamon and cook over moderately low heat, stirring, until fragrant, about 1 minute.\\r\\n\\r\\nAdd the soy sauce, sake, oyster sauce, mirin, sugar and 1/3 cup of water and bring to a simmer over moderate heat. Cover and simmer for 10 minutes. Uncover and cook over moderately high heat, stirring occasionally, until the wings are cooked through and the sauce has reduced to a thick glaze, about 8 minutes. Discard the chiles, star anise and cinnamon. Transfer the chicken wings to a platter, scatter the scallions on top and serve.\\r\\n\\r\\nGood with coconut rice and napa cabbage slaw (sesame oil and rice vinegar dressing).\\r\\n", "sources": ["https://andrewzimmern.com/2012/09/17/one-pot-sticky-chicken-wings/", "https://www.foodandwine.com/recipes/one-pot-sticky-chicken-wings"], "ingredients": [{"name": "chicken wings, wing tips removed and wings cut into 2 pieces", "quantity": "3 pounds"}, {"name": "minced fresh ginger", "quantity": "2 tablespoons"}, {"name": "dried red chiles", "quantity": "4 small"}, {"name": "star anise", "quantity": "2 whole"}, {"name": "One 3-inch cinnamon stick"}, {"name": "soy sauce", "quantity": "1/3 cup"}, {"name": "sake", "quantity": "1/3 cup"}, {"name": "oyster sauce (or hoisin)", "quantity": "3 tablespoons"}, {"name": "mirin", "quantity": "3 tablespoons"}, {"name": "sugar", "quantity": "3 tablespoons"}, {"name": "water", "quantity": "1/3 cup"}, {"name": "scallions, thinly sliced", "quantity": "2"}]}	2018-09-23 19:15:14.052	2018-09-23 19:15:14.052
9f932435-5c77-48af-98a5-e99737524630	1	{"title": "Bean Salad", "method": "", "sources": [], "ingredients": [{"name": "Chick Peas"}, {"name": "English Cucumber"}, {"name": "Red Bell Pepper"}, {"name": "Snoino"}, {"name": "Parsley"}, {"name": "Olive Oil"}, {"name": "Cider Vinegar"}, {"name": "Salt"}, {"name": "Pepper"}]}	2014-07-03 16:36:40	2014-07-03 16:38:24
aea7e5c0-7fe2-482b-a7a4-eb87cbcfbe15	1	{"title": "Tacos (Slow-Roasted Pork)", "method": "Add pork, crushed dried chilies, cumin, paprika, smoke, salt, pepper, and garlic to crock. Cook on high for 4-5 hours. When pork is almost done, sauté onions and poblano with olive oil. Shred pork and combine with onions and poblano. Add some lime juice.\\r\\n\\r\\nOther Stuff\\r\\n\\r\\n* Tortillas\\r\\n* Avocado\\r\\n* Bell Pepper\\r\\n* Hot Sauce\\r\\n* Chihuahua Cheese\\r\\n\\r\\n", "sources": [], "ingredients": [{"name": "Pork Shoulder"}, {"name": "Guajillo chilies", "quantity": "3 dried"}, {"name": "Cumin"}, {"name": "Smoked Paprika"}, {"name": "Liquid Smoke"}, {"name": "Salt & Pepper"}, {"name": "Garlic (3 cloves)"}, {"name": "Snoino"}, {"name": "Poblano Pepper"}, {"name": "Lime Juice"}]}	2018-09-29 13:00:25.127	2018-09-29 13:00:25.127
32446843-3d56-4d42-8f22-1f44e3bcf010	1	{"title": "Hungarian Gulash", "method": "1. Brown Meat\\r\\n1. Saute onion\\r\\n1. Put all in crock but peas\\r\\n1. Cook on high for 4+ hours\\r\\n1. Add peas\\r\\n1. Server over noodles\\r\\n", "sources": [], "ingredients": [{"name": "Beef", "quantity": "1-2 lbs"}, {"name": "Snoino"}, {"name": "Garlic"}, {"name": "Tomato Sauce (or Ketchup)", "quantity": "3/4 cup"}, {"name": "Worcestershire Sauce", "quantity": "1/4 cup"}, {"name": "vinegar", "quantity": "1-2 T"}, {"name": "Paprika", "quantity": "2 1/2 tsp."}, {"name": "dry mustard", "quantity": "1 tsp."}, {"name": "black pepper"}, {"name": "cut into half coins", "quantity": "3 Carrots"}, {"name": "Peas"}]}	2018-11-05 00:05:27.116	2018-11-05 00:05:27.116
483adebd-f6ea-4b47-90fa-492f838a6f7b	1	{"title": "Poached Chicken", "method": "1. Put chicken and bay leaves in a pot. Try to arrange chicken in a single layer. Sprinkle with salt and peppercorns.\\r\\n2. Cover chicken with cool water by about an inch.\\r\\n3. Bring water to a boil.\\r\\n4. Reduce to a simmer, cover, and cook. Begin checking at about 8 minutes. Chicken will take 10-15 minutes.\\r\\n\\r\\n\\r\\n", "sources": ["https://www.thekitchn.com/how-to-poach-chicken-breasts-cooking-lessons-from-the-kitchn-28367"], "ingredients": [{"name": "Chicken Breast"}, {"name": "Bay Leaves"}, {"name": "Black Peppercorns "}]}	2018-06-11 22:38:55.332	2018-06-11 22:38:55.332
b81cb42f-74b8-4606-8640-d76a9c559de9	1	{"title": "Braised and Glazed Brussels Sprouts", "method": "1. Combine butter, sprouts, and liquid. Sprinkle with salt and pepper then bring to a boil.\\r\\n2. Adjust heat to simmer. Cover and cook until sprouts are tender (5-10 minutes).\\r\\n3. Uncover and raise heat to boil off all the liquid. Cook until glazed and then browned. Don't stir them too frequently.\\r\\n\\r\\n\\r\\n", "sources": ["Mark Bittman, How to Cook Everything"], "ingredients": [{"name": "Brussels Sprouts"}, {"name": "Butter and/or Olive Oil"}, {"name": "stock, white wine, or water", "quantity": "1/2 cup"}]}	2018-09-29 20:41:51.735	2018-09-29 20:41:51.735
c9ec8a9c-c656-4faa-b11e-a1febbba9417	1	{"title": "Beans and Rice II", "method": "1. Soak beans. \\r\\n2. Chop bacon into pieces. Cook bacon in dutch oven until some of the fat has rendered. Remove bacon and discard rendered fat. Return bacon and chopped onions, celery, and bell pepper to dutch oven and cook until vegetables soften. Add garlic.\\r\\n3. Add soaked beans, thyme, bay leaf, a bit of smoked paprika, a dash of cayenne, and plenty of black pepper. Cover beans with about two inches of water and bring to a boil. Reduce to a simmer and cook until tender (1 1/2 to 2 hours).\\r\\n4. When beans are nearly done, cook rice like for a pilaf or Mexican rice, including the tomatoes.\\r\\n5. When rice is nearly done, add chopped spinach.\\r\\n6. When both beans and rice are done, combine them together with a few splashes of cider vinegar and serve with some hot sauce.\\r\\n\\r\\n", "sources": ["https://www.seriouseats.com/recipes/2017/05/new-orleans-style-red-beans-rice-recipe.html"], "ingredients": [{"name": "Beans (reddish)"}, {"name": "Bay leaf"}, {"name": "Paprika"}, {"name": "Thyme"}, {"name": "Rice"}, {"name": "Tomatoes"}, {"name": "Onion"}, {"name": "Bell pepper"}, {"name": "Celery"}, {"name": "Garlic"}, {"name": "Stock"}, {"name": "Greens (spinach)"}, {"name": "Cider vinegar"}, {"name": "Bacon", "quantity": "3-5 slices"}]}	2018-06-23 22:04:47.858	2018-06-23 22:04:47.858
ef67d049-591d-400d-a70a-6a526c7c34a6	1	{"title": "Duck Legs with Aromatic Vegetables", "method": "1. Heat oven to 400°F.\\r\\n2. Brown duck legs thoroughly and evenly with skin side down.\\r\\n3. Once browned, turn legs and sear 1-2 minutes.\\r\\n4. Transfer legs to a plate and sprinkle with salt and pepper.\\r\\n5. Reserve enough fat to moisten the veggies, and remove the rest.\\r\\n6. Cook veggies over medium-high heat with some salt and pepper until browned (10-15 minutes).\\r\\n7. Return the duck legs to the pan skin side up. Add stock (it should come about half way up the duck).\\r\\n8. Turn heat to high and bring to a boil. Transfer to the oven.\\r\\n9. Cook for 30 minutes, then reduce heat to 350°F.\\r\\n10. Cook until duck is tender and the liquid reduced (about 30 more minutes).\\r\\n\\r\\n", "sources": ["Mark Bittman, How to Cook Everything"], "ingredients": [{"name": "Duck Legs"}, {"name": "Onion"}, {"name": "Carrots"}, {"name": "Stalks", "quantity": "3 Celery"}, {"name": "Stock", "quantity": "2 cups"}]}	2018-10-20 23:39:49.559	2018-10-20 23:39:49.559
cb7e47fc-18ba-46ec-8800-493a80f58ac8	1	{"title": "Spanish Rice", "method": "", "sources": [], "ingredients": [{"name": "Short brown rice"}, {"name": "Bell pepper"}, {"name": "Mushrooms"}, {"name": "Chorizo"}, {"name": "Snoino"}, {"name": "Tomatoes"}, {"name": "Corn"}, {"name": "Smoked paprika"}, {"name": "Garlic"}]}	2012-10-20 16:36:05	2016-10-19 21:21:16
4b33e407-1654-4ab3-a44c-5dd527a233d6	1	{"title": "Wild Rice Pilaf", "method": "1. Cook rice in hot fat until fragrant.\\r\\n2. Add liquid and bring to a boil.\\r\\n3. Cover and turn heat to low. Cook 30 minutes.\\r\\n4. Rice is done when liquid is absorbed and rice is tender.", "sources": [], "ingredients": [{"name": "Wild Rice"}, {"name": "3:1 stock or water"}, {"name": "Aromatics"}, {"name": "Bay leaf"}]}	2018-11-22 01:59:53.387	2018-11-22 01:59:53.387
6bc7abed-131b-43d4-a02b-d787a14d1d7f	1	{"title": "\\"Mexican\\" Chicken Casserole", "method": "", "sources": [], "ingredients": [{"name": "Chicken Breast"}, {"name": "Mild Chili"}, {"name": "Red Bell Pepper"}, {"name": "Snoino"}, {"name": "Garlic"}, {"name": "Dried Chili"}, {"name": "Tomatoes"}, {"name": "Stock"}, {"name": "Long Grain White Rice"}, {"name": "Cheddar Cheese"}]}	2012-10-14 16:58:05	2014-03-11 21:54:01
931781ff-2349-4507-b544-cb21bb47b796	1	{"title": "Arroz con Pollo", "method": "Warm the stock and water while cooking onions.\\r\\n\\r\\nSaute onions in olive oil with some salt and pepper. When onions are soft, add rice and stir.\\r\\n\\r\\nWhile onions and rice are going, remove skin from chicken.\\r\\n\\r\\nAdd all spice turmeric, bell pepper, and garlic. Stir.\\r\\n\\r\\nNestle chicken in rice. Add some more salt and pepper. Pour in stock and water. Bring to a boil. Adjust heat to gentle bubbles.\\r\\n\\r\\nCover and cook 20 minutes.\\r\\n\\r\\nTurn heat all the way down and add peas. Cook about 10 minutes more.", "sources": ["Mark Bittman"], "ingredients": [{"name": "Stock", "quantity": "2 cups"}, {"name": "water", "quantity": "2 cups"}, {"name": "Snoino"}, {"name": "Arborrio Rice", "quantity": "2 cups"}, {"name": "Allspice"}, {"name": "Turmeric"}, {"name": "Chicken thighs, bone in, skin removed"}, {"name": "Garlic"}, {"name": "Red Bell Pepper"}, {"name": "Peas"}]}	2018-05-28 19:59:05.022	2018-05-28 19:59:05.022
98959038-8d24-47a8-9303-4ca6115b2423	1	{"title": "Chicken Curry (Indian-Style w/Coconut Milk)", "method": "Brown chicken. Set aside.Sauté onions and carrots. Add curry and garlic when aromatics have softened. Add tomatoes and coconut milk. Bring to a boil. Reduce to a brisk simmer. Add chicken and accumulated juices. Simmer partially covered for 15-20 minutes.\\r\\n\\r\\nServer over brown basmati rice.", "sources": ["http://www.epicurious.com/recipes/food/views/Chicken-Curry-237212"], "ingredients": [{"name": "Boneless, skinless chicken thighs"}, {"name": "Coconut milk"}, {"name": "Tomatoes (14.5 oz can)"}, {"name": "Onions"}, {"name": "Carrots"}, {"name": "garlic", "quantity": "3 cloves"}, {"name": "curry powder"}, {"name": "cayenne"}]}	2012-10-14 17:16:32	2013-02-06 13:53:12
78b2115b-c611-49e6-a69b-40770265211e	1	{"title": "Beef Stew", "method": "1. Turn crock to high.\\r\\n2. Brown beef with salt and pepper and add to crock.\\r\\n2. Fry onions until beginning to soften. Add 1-2 tbps flour to onions and cook for about 1 minute more. Turn off heat, add about 1 cup red wine to pan and scrape all the bits from the bottom of the pan. Add all to crock.\\r\\n3. Peel and chop carrots into chunks. Add to crock.\\r\\n4. Scrub potatoes and chop into chunks. Add to crock.\\r\\n5. Mince 2-3 cloves of garlic and add to crock.\\r\\n6. Add thyme and bay leaf.\\r\\n7. Add stock until contents are almost covered and stir.\\r\\n8. Cook in crock on high for 4-6 hours.\\r\\n9. Add peas.\\r\\n", "sources": [], "ingredients": [{"name": "Beef (cut into bite-sized pieces)"}, {"name": "Garlic"}, {"name": "Snoino"}, {"name": "Beef or Mushroom Stock"}, {"name": "Potatoes (4)"}, {"name": "Carrots (4)"}, {"name": "Peas"}]}	2019-05-09 15:55:46.74	2019-05-09 15:55:46.741
9ccb62bf-3857-43e0-b1d6-51eb65aaa177	1	{"title": "Beef and Barley Stew", "method": "1. Brown beef in batches; add to crock.\\r\\n1. Sauté snoino; add to crock.\\r\\n1. Add everything else.\\r\\n1. Cook on high for 4-5 hours.", "sources": [], "ingredients": [{"name": "Beef"}, {"name": "at least 3 cups stock."}, {"name": "snoino", "quantity": "1-2"}, {"name": "Carrots", "quantity": "2-3"}, {"name": "Turnips", "quantity": "1-2"}, {"name": "Can Tomatoes", "quantity": "14 oz."}, {"name": "Celery"}, {"name": "barley", "quantity": "1/3 - 1/2 cup"}, {"name": "garlic"}, {"name": "paprika (smoked)"}, {"name": "Thyme"}, {"name": "bay leaf"}]}	2012-10-14 16:56:12	2013-02-11 01:05:57
49b844a3-8df8-43a2-ad47-9fecd0523e6a	1	{"title": "Braised Lamb Leg Steak", "method": "Brown steak and set aside. Brown onions, parsnips, and celery. While aromatics cook, put tomatoes, garlic, and some of the wine in a slow cooker. When aromatics are ready, add them to the slow cooker. Add chopped rosemary. Submerge lamb. Add rest of wine. Cook for 4-5 hours on high.\\r\\n\\r\\nGood with bread and green beans.", "sources": [], "ingredients": [{"name": "~1.5 Lb Lamb Leg Steak"}, {"name": "or 2 medium onions", "quantity": "1 large"}, {"name": "can tomatoes", "quantity": "1 14.5 oz"}, {"name": "or 4 small parsnips", "quantity": "2 large"}, {"name": "carrots", "quantity": "2 medium"}, {"name": "stalk", "quantity": "1 celery"}, {"name": "garlic", "quantity": "4 cloves"}, {"name": "fresh rosemary", "quantity": "2 sprigs"}, {"name": "red wine", "quantity": "1-2 cups"}]}	2013-02-05 23:29:40	2013-02-06 13:47:29
072aaaeb-1173-425d-81d3-7acaca5f97d9	1	{"title": "Chicken & Chick Pea Curry", "method": "Sauté onions. Add carrots. Add spices and garlic. Add stock. Add tomatoes. Add chick peas. Add chicken. Simmer until \\"done\\". Server over brown basmati rice.", "sources": [], "ingredients": [{"name": "Chicken"}, {"name": "Carrots"}, {"name": "Snoino"}, {"name": "Garlic"}, {"name": "Tomatoes"}, {"name": "Chick Peas"}, {"name": "Stock"}, {"name": "Curry spices"}, {"name": "Brown basmati rice"}]}	2014-02-05 16:25:16	2014-02-05 16:27:57
08c69a22-4c06-40e9-b0a1-9aabb8c71c4b	1	{"title": "Chicken & Veggie Pita", "method": "Saute veggies with garlic. Pan fry chicken.", "sources": [], "ingredients": [{"name": "Broccoli"}, {"name": "Summer Squash"}, {"name": "Bell pepper"}, {"name": "Onions"}, {"name": "Garlic"}, {"name": "Chicken Tenders"}, {"name": "Hummus (roasted red pepper is good)"}]}	2014-08-03 19:56:32	\N
78c2a8f6-d4ad-4ea4-951a-d2563f2f753d	1	{"title": "Chicken Adobo", "method": "Begin heating oven to 450°.\\r\\n\\r\\nCombine soy sauce, vinegar, coconut milk, garlic, bay leaves, and plenty of black pepper in a pan. Bring to a boil, add the chicken, then turn to medium low. Cover and cook, turning the chicken at least once, for about 20 minutes.\\r\\n\\r\\nRemove chicken from sauce and place in a pan skin side up. Boil sauce until reduced, then remove bay leaves and keep warm over low heat. Roast chicken for 5-10 minutes.\\r\\n\\r\\nSee Mark Bittman for original recipe (use coconut milk and halve the recipe for 4 thighs).\\r\\n\\r\\nServe with white rice and stir-fried veggies (chard with onion and garlic is good).", "sources": [], "ingredients": [{"name": "Soy sauce", "quantity": "1/2 cup"}, {"name": "Vinegar", "quantity": "1/4 cup"}, {"name": "Garlic, chopped", "quantity": "2-4 cloves"}, {"name": "Leaves", "quantity": "2 Bay"}, {"name": "Light Coconut Milk", "quantity": "1 can"}, {"name": "Chicken"}]}	2015-01-28 14:56:37	2016-12-05 14:30:44
94449d5f-44ba-42c7-a472-18f4685ea6e3	1	{"title": "Chicken Shwarma", "method": "", "sources": [], "ingredients": [{"name": "Chicken"}, {"name": "Snoino"}, {"name": "Garlic"}, {"name": "Oregano"}, {"name": "Tomatoes"}, {"name": "Lettuce"}, {"name": "Lavash Pita Bread"}, {"name": "Mayo"}]}	2012-11-13 20:43:09	2012-11-13 22:07:43
d503b853-b700-467a-8420-a66b3c5037be	1	{"title": "Chicken Soup with Kale", "method": "Braise chicken thighs for about one hour in about 1/2 cup white wine with garlic and thyme.\\r\\n\\r\\nSauté onions, celery, and carrots until they begin to soften. Add bell pepper. Add stock. Add kale.\\r\\n\\r\\nWhen chicken is done, remove chicken from bones and chop into pieces. Add chicken, smashed garlic, and cooking liquid to soup.", "sources": [], "ingredients": [{"name": "Chicken thighs (skin removed, bone in)"}, {"name": "Wine"}, {"name": "Garlic"}, {"name": "Fresh Thyme"}, {"name": "Onion"}, {"name": "Celery"}, {"name": "Carrots"}, {"name": "Red Bell Pepper"}, {"name": "Kale"}, {"name": "Stock"}]}	2015-10-28 16:41:59	2015-10-28 16:44:31
6fb7334c-9dda-4460-b14c-999516b3d86f	1	{"title": "Chicken and Cabbage with Polenta", "method": "Roast the chicken with Mexican rub.\\r\\n\\r\\nCook the cabbage with poblano, onion, caraway, and some cumin. Finish with lime juice.\\r\\n\\r\\nMelt some cheese on the polenta.", "sources": [], "ingredients": [{"name": "Chicken"}, {"name": "Mexican rub"}, {"name": "Cabbage"}, {"name": "Poblano"}, {"name": "Onion"}, {"name": "Garlic"}, {"name": "Caraway"}, {"name": "Polenta"}, {"name": "Cheese"}]}	2017-11-25 22:28:13	2017-11-25 22:30:16
54b3e40b-c29f-499d-9850-16bf6aa2aca8	1	{"title": "Chili", "method": "Sauté onions. When onions start getting soft, add beef and brown until all traces of pink are gone. Add dried chili, smoked paprika, and cumin. Add bell pepper. In a couple of minutes, add tomatoes and stock. Let burble for a couple more minutes. Add black beans and garlic.\\r\\n\\r\\nLet everything cook for a while. About 10-15 minutes before serving, add oregano and a dash of lime juice.", "sources": [], "ingredients": [{"name": "Beef"}, {"name": "Black Beans (big, with juice)"}, {"name": "Tomatoes (small, with juice)"}, {"name": "Stock (1 cup)"}, {"name": "Red Bell Pepper"}, {"name": "Snoino"}, {"name": "Garlic"}, {"name": "Dried Chili (ground or whole)"}, {"name": "Cumin (at least 1 tsp)"}, {"name": "Smoked Paprika (a good few shakes)"}, {"name": "Oregano"}, {"name": "Lime Juice"}, {"name": "Cheese"}, {"name": "Chips"}]}	2018-06-02 13:55:42.788	2018-06-02 13:55:42.788
a0b7aa68-66d9-4dd7-a2c3-01b1660bcf75	1	{"title": "Coconut Rice", "method": "Bring all to a boil. Reduce heat to low and cook for about 20 minutes.", "sources": [], "ingredients": [{"name": "jasmine rice", "quantity": "2 cups"}, {"name": "liquid (coconut milk and water)", "quantity": "3 cups"}, {"name": "salt"}]}	2015-02-22 15:20:16	2015-02-22 15:21:36
4368e8b2-78e3-4824-a6bb-3b51abf581a5	1	{"title": "Dal", "method": "Serve over brown basmati rice.", "sources": [], "ingredients": [{"name": "onions", "quantity": "1-2"}, {"name": "or 1/2 large cauliflower", "quantity": "1 small"}, {"name": "or 2 small carrots, minced", "quantity": "1 large"}, {"name": "tomatoes", "quantity": "1 can"}, {"name": "stock", "quantity": "1 cup"}, {"name": "2+ cups water"}, {"name": "red lentils", "quantity": "1 cup"}, {"name": "Fennel seed"}, {"name": "Coriander"}, {"name": "Cumin"}, {"name": "Garam Masala"}, {"name": "Maharaja curry powder"}, {"name": "Garlic"}]}	2012-10-17 19:10:33	2013-09-20 22:42:21
24b1ac9d-bb11-441c-8e92-a8ebba7375b3	1	{"title": "Chicken Quesadillas", "method": "Braise kale with onion, bell pepper, and a bit of lime juice. Marinate chicken tenders. Grill or fry chicken. Make quesadillas. Serve with sliced avocado and salsa.\\r\\n", "sources": [], "ingredients": [{"name": "Chicken"}, {"name": "Tortillas"}, {"name": "Cheese (chihuahua and/or cheddar)"}, {"name": "Salsa"}, {"name": "Avocado"}, {"name": "Garlic"}, {"name": "Lime Juice"}, {"name": "Kale or chard"}, {"name": "Bell pepper (green)"}, {"name": "Onion"}]}	2018-07-04 13:27:22.501	2018-07-04 13:27:22.501
b8e26fc3-b14c-4efe-a94e-c56513c26906	1	{"title": "Grilled Chicken & Chickpea Pasta Salad", "method": "Marinate chicken in sherry and/or cider vinegar and olive oil. Grill chicken.\\r\\n\\r\\nCook pasta and drain. Combine pasta and spinach to wilt spinach.\\r\\n\\r\\nChill pasta and chicken.\\r\\n\\r\\nMake dressing with olive oil, vinegars, garlic (can be mellowed by roasting in olive oil), sage, and oregano.\\r\\n\\r\\nOnce pasta and chicken are sufficiently chilled, combine with dressing, chickpeas, bell pepper, onion, and sage.", "sources": [], "ingredients": [{"name": "Chicken (boneless, skinless thighs)"}, {"name": "Chickpeas"}, {"name": "Spinach, coarsely chopped"}, {"name": "Bell Pepper"}, {"name": "Snoino"}, {"name": "Garlic"}, {"name": "Pasta"}]}	2015-07-02 15:59:33	2015-07-02 16:04:50
9fd62dde-a637-4cc8-948c-93c244075e8b	1	{"title": "Lamb Meatballs", "method": "Heat oven to 380°F. Bake meatballs 18-20 minutes (until heated to 160°F).\\r\\n\\r\\nGood with brown rice and mushroom pilaf (see Bittman) and veggies.", "sources": [], "ingredients": [{"name": "Lamb"}, {"name": "Parsley"}, {"name": "Garlic"}, {"name": "Snoino"}, {"name": "Coriander"}, {"name": "Cumin"}, {"name": "Cinnamon"}, {"name": "Egg", "quantity": "1"}]}	2015-05-11 00:11:26	\N
49ddfc25-cd0b-42a4-89e9-3844d5f800bf	1	{"title": "Lamb and Root Vegetable Stew", "method": "Didn't use peas first time around, but I think they'd be a tasty addition. Cooked ~4-5 hours on high. Would have been tasty with crusty bread.", "sources": [], "ingredients": [{"name": "Lamb (1-2lb) (browned before adding to crock)"}, {"name": "Snoino (sauteed after browning lamb and deglazed with beer)"}, {"name": "Carrots", "quantity": "2"}, {"name": "Parsnips", "quantity": "2"}, {"name": "or Rutabagas or Mix", "quantity": "3 Turnips"}, {"name": "Peas"}, {"name": "stock", "quantity": "1 cup"}, {"name": "~3/4 12oz bottle brown ale"}, {"name": "water", "quantity": "1-1.5 cups"}, {"name": "Bay leaf"}, {"name": "Garlic"}, {"name": "Thyme"}, {"name": "Rosemary"}, {"name": "Coriander"}]}	2012-10-17 18:48:57	2012-10-17 18:52:19
ce004e0b-178c-4c8f-b80f-12ef600be84b	1	{"title": "Lentil and Barley Soup", "method": "1. Toast barley with olive oil until lightly browned (like for a pilaf), and then start to simmer in 1 1/2 cup water with bay leaf.\\r\\n1. Chop and sauté aromatics (celery, onion and carrots) in a separate pot with some salt and pepper.\\r\\n1. Add lentils, stock and 1 cup water to barley.\\r\\n1. After the onions has softened and become translucent, add tomatoes to aromatics.\\r\\n1. Let everything hang out for a bit (10-15 minutes). Add barley and lentils to everything else. Add paprika and cayenne. Add garlic. Simmer partly covered until done, adding more water if necessary.", "sources": [], "ingredients": [{"name": "barley", "quantity": "1/3 cup"}, {"name": "green lentils", "quantity": "2/3 cup"}, {"name": "red lentils", "quantity": "1/3 cup"}, {"name": "Onion"}, {"name": "carrots", "quantity": "2 small"}, {"name": "Celery", "quantity": "1-2 stalks"}, {"name": "Garlic", "quantity": "2-3 cloves"}, {"name": "can Tomatoes", "quantity": "1 14.5 oz"}, {"name": "stock", "quantity": "2 cups"}, {"name": "water", "quantity": "3 cups"}, {"name": "Bay leaf"}, {"name": "Smoked paprika"}, {"name": "Dash cayenne"}]}	2012-12-28 01:46:52	2013-11-22 14:08:06
4810f571-741d-47cb-82f2-d71892410aeb	1	{"title": "Tacos (Red Chili Chicken)", "method": "Other Stuff\\r\\n\\r\\n* Tortillas\\r\\n* Avocado\\r\\n* Bell Pepper\\r\\n* Queso Fresco\\r\\n* Salsa\\r\\n* Chips\\r\\n", "sources": [], "ingredients": [{"name": "Chicken Tenders (or Breast)"}, {"name": "Dried Chili (Pasilla or Ancho)"}, {"name": "Garlic"}, {"name": "Lime Juice"}, {"name": "Chipotle"}, {"name": "Cumin"}, {"name": "Oregano"}]}	2018-06-09 19:32:33.471	2018-06-09 19:32:33.471
5d9f56b2-5fb0-41ce-a2c5-cdd5e43fa06c	1	{"title": "Mexican Chicken Hash", "method": "Marinate chicken in chipotle, cumin, paprika, salt pepper garlic, lime, and oil. Coat potatoes with olive oil, cumin, smoked paprika, salt and pepper. Start potatoes roasting in 425 oven. After 15 minutes or so, stir the taters, pile them on the sides, and add the chicken. Sauté cabbage and onions with some carraway. After chicken and taters have roasted for another 20-30 minutes, remove the chicken and chop it up. Add everything to the cabbage and stir it.\\r\\n\\r\\nEat with Mean Green hot sauce.", "sources": [], "ingredients": [{"name": "Potatoes"}, {"name": "Chicken"}, {"name": "Snoino"}, {"name": "Cabbage"}, {"name": "Garlic"}, {"name": "Lime juice"}]}	2014-03-26 00:10:04	2014-03-26 00:16:06
200848b4-4192-4f0f-8f8e-b1d4aa119657	1	{"title": "Mushroom Bacon Pasta", "method": "Sear mushrooms in a little olive oil with salt and pepper. After mushrooms are going good, place in 425 degree oven to roast (toss them occasionally).\\r\\n\\r\\nChop bacon and fry until starting to crisp. Remove bacon to paper towel and reserve a small amount of the fat. Fry onions and diced carrots until beginning to brown and soften.\\r\\n\\r\\nHeat about 2 cups of mushroom broth with about half a small can of tomato paste. Simmer and reduce. Add thyme, oregano, and marjoram.\\r\\n\\r\\nAdd spinach to onions and carrots (maybe a splash of white wine). When wilted, add garlic, mushrooms, and bacon. Keep on low heat.\\r\\n\\r\\nAdd fontina to tomato mushroom sauce and whisk.\\r\\n\\r\\nCombine spinach and mushrooms with pasta. Stir in sauce.", "sources": [], "ingredients": [{"name": "Mushrooms"}, {"name": "thick Bacon", "quantity": "4 strips"}, {"name": "Carrots", "quantity": "2"}, {"name": "Snoino"}, {"name": "Spinach"}, {"name": "Mushroom Broth"}, {"name": "Tomato Paste"}, {"name": "Garlic"}, {"name": "Fontina Cheese"}]}	2015-12-10 14:52:57	2015-12-10 15:01:38
9ad7546b-156b-43fe-b100-a18e457e6be5	1	{"title": "Neeps & Tatties", "method": "Peel and cube \\"neeps\\", put in pan with boiling water. Peel and cube taters. Add taters to pan after about 10-15 minutes. Boil for 15-20 minutes more (a total of 30-40 minutes) until both are tender.\\r\\n\\r\\nIn the meantime, roast some garlic.\\r\\n\\r\\nMash root vegetables with butter and roasted garlic (some stock can be added too).", "sources": [], "ingredients": [{"name": "Turnip or Rutabaga ", "quantity": "1 part"}, {"name": "Potatoes", "quantity": "2 parts"}, {"name": "Garlic"}, {"name": "Butter"}]}	2016-04-04 22:18:00	2016-04-04 22:22:38
39f1065f-8fb4-4fb6-bd90-d0e1c5fb559c	1	{"title": "Polenta with White Beans and Chicken", "method": "Sauce: Simmer tomatoes with a little olive oil and garlic. Add spinach. Add beans.\\r\\n\\r\\nChicken: Heat oil in cast iron. Cook chicken flat with salt and pepper. Finish with a little balsamic vinegar.\\r\\n\\r\\nServe chicken with polenta and sauce and some grated parmesan.", "sources": [], "ingredients": [{"name": "Tomatoes"}, {"name": "Garlic"}, {"name": "Spinach"}, {"name": "Cannellini Beans"}, {"name": "Chicken (boneless skinless thighs)"}, {"name": "Polenta"}]}	2017-01-20 00:45:45	\N
bcac6ff6-abb5-4ad2-9cf9-4d82a246669a	1	{"title": "Roasted Boneless Skinless Chicken Thighs", "method": "Marinate chicken (balsamic garlic is good) for ~1 hour. Roast in 425° oven for around 20 minutes.\\r\\n\\r\\nGood with fried potatoes and a veggie (like steamed broccoli).\\r\\n", "sources": [], "ingredients": [{"name": "Chicken"}]}	2018-06-09 19:18:04.093	2018-06-09 19:18:04.093
653ead49-c3c0-41f4-bdec-3894a6db5c98	1	{"title": "Pork Belly", "method": "1. Season pork belly with salt sugar and a few grinds of black pepper. Cover and refrigerate overnight.\\r\\n1. Preheat oven to 450°F.\\r\\n1. Roast pork belly for 30 minutes, fat side up. Reduce heat to 275°F and roast for an hour or more, until tender but not mushy. (Larger pieces of pork belly will take longer. Our one-pound belly was done after an hour at 275°F.)\\r\\n1. Remove from oven and let cool to room temperature. Wrap tightly in plastic and refrigerate until chilled through - at least a few hours and up to 2 days.\\r\\n1. Once chilled, slice into thick pieces and brown in a small amount of oil or warm in stock or water.", "sources": ["https://pinchandswirl.com/oven-roasted-crispy-pork-belly/"], "ingredients": [{"name": "skinless pork belly", "quantity": "1 pound"}, {"name": "fine salt", "quantity": "2 teaspoons"}, {"name": "sugar", "quantity": "2 teaspoons"}, {"name": "few grinds of black pepper"}]}	2018-01-03 20:21:51	2018-03-11 19:03:45
33d03d73-2af9-4f5d-9baa-d523ea40cf6d	1	{"title": "Pork and Cabbage Stir Fry", "method": "Chop cabbage. Julienne carrots (1-1.5\\"). Chop green onions.\\r\\n\\r\\nSauce: combine generous portion of grated ginger, garlic, rice vinegar, sriracha, and soy sauce.\\r\\n\\r\\nBrown pork with chili flakes and black pepper. When almost cooked through, add the sauce. Add hoisin. Add carrots (want them cooked a bit, but still crunchy). Add cabbage (same as carrots). Just before serving, add green onions.\\r\\n\\r\\nServe over jasmine rice.", "sources": [], "ingredients": [{"name": "Ground Pork"}, {"name": "Cabbage"}, {"name": "Carrots (1 large or 2 medium)"}, {"name": "Green Onions"}, {"name": "Ginger"}, {"name": "Garlic"}, {"name": "Rice Vinegar"}, {"name": "Soy Sauce"}, {"name": "Sriracha "}, {"name": "Hoisin"}, {"name": "Chili Flakes"}]}	2017-12-31 18:43:41	2018-03-31 13:07:29
9de15ee0-182b-42a3-8996-c64f3a4e7d8e	1	{"title": "Roasted Cauliflower", "method": "", "sources": [], "ingredients": [{"name": "Preheat over to 400 degrees."}, {"name": "Separate cauliflower into florets."}, {"name": "Toss cauliflower in roasting pan with salt, pepper, and 2-3 tablespoons of olive oil."}, {"name": "When oven is preheated, roast for about 30 minutes total. Toss or stir every 10-15 minutes."}, {"name": "When done roasting, remove from oven and add a few dashes of sherry vinegar."}]}	2015-01-29 14:08:32	2015-01-29 14:12:05
97568572-1aa4-416c-b1b6-4f09e741a7ff	1	{"title": "Sausage & Starch", "method": "Starch Options* Potatoes\\r\\n* Rice Pilaf\\r\\n* Quinoa\\r\\nEspecially good with greens.", "sources": [], "ingredients": [{"name": "Sausage"}]}	2012-10-24 13:16:33	2012-10-24 13:18:11
b1a6f41d-11cc-4bcb-83a0-0e6f1064cce2	1	{"title": "Shrimp Kabobs", "method": "", "sources": [], "ingredients": []}	2013-08-17 16:10:20	2013-08-17 16:10:26
ac7fa8d6-7999-46e4-b04f-c8087db3ca8a	1	{"title": "Southwest Pulled Chicken", "method": "Add chicken, olive oil, lime juice, ground guajillo chilies, paprika, cumin, salt and pepper to crock pot on high. Sauté onion and poblano and add to crock (any time up to an hour before done). Cook 4-5 hours and shred. Check seasoning and serve on buns withguacamole,cheese, and hot sauce.\\r\\n\\r\\nSides\\r\\n\\r\\nGood with coleslaw made with cabbage, red pepper, and cilantro. Dress with lime juice, cider vinegar, and olive oil.", "sources": [], "ingredients": [{"name": "Guajillo chilies", "quantity": "2 dried"}, {"name": "Chicken"}, {"name": "Smoked Paprika"}, {"name": "Cumin"}, {"name": "Pepper"}, {"name": "Snoino"}, {"name": "Oregano"}, {"name": "Poblano Pepper"}, {"name": "Olive Oil"}, {"name": "Lime Juice"}, {"name": "Avocado"}, {"name": "Garlic"}, {"name": "Chihuahua Cheese"}, {"name": "Buns"}, {"name": "Hot Sauce"}]}	2014-04-07 12:59:59	2014-04-07 13:15:24
7c283e0b-2dca-43b6-9e98-e91d54c0138a	1	{"title": "Stir Fry", "method": "", "sources": [], "ingredients": [{"name": "http://www.geniuskitchen.com/recipe/big-bowls-kung-pao-chicken-copycat-301758"}]}	2018-06-09 19:21:03.937	2018-06-09 19:21:03.937
8c76bc57-1043-431b-afb7-17f852805f28	1	{"title": "Stewed Chicken and Garlic", "method": "1. Brown chicken on all sides.\\r\\n2. Add garlic,  cinnamon, and parsley.\\r\\n3. Pour liquid and bring to a boil.\\r\\n4. Reduce heat until bubbling gently.\\r\\n5. Cook about 1 hour.\\r\\n\\r\\nSides\\r\\n\\r\\n* Broccoli\\r\\n* Sweet Potatoes\\r\\n\\r\\n", "sources": [], "ingredients": [{"name": "Chicken"}, {"name": "White Wine"}, {"name": "Garlic (at least 1 head)"}, {"name": "Parsley (optional)"}]}	2018-11-08 23:21:53.455	2018-11-08 23:21:53.455
8e05123e-d6c2-4024-b1f1-44e5c99388c5	1	{"title": "Pork Chops with Rice and Tomatoes", "method": "1. Start rice.\\r\\n1. Dice onion and begin cooking with olive oil in large pan.\\r\\n2. Chop carrots into coins and add to onion.\\r\\n3. Mince garlic and add to pan when onion begins to soften.\\r\\n4. When onion is beginning to brown, add diced tomatoes and thyme and bring to a boil.\\r\\n5. Reduce heat to low and cover. Cook for about 30 minutes.\\r\\n6. Add tomato sauce, marjoram, oregano, and basil to pan. Bring to a boil.\\r\\n7. Reduce heat back to low and cover.\\r\\n8. Cook for about 15 more minutes.\\r\\n9. Heat oil in a cast iron pan. Brown pork chops (about 2 minutes per side).\\r\\n10. Transfer chops to sauce. Cook for about 10 more minutes turning once until pork is done.\\r\\n11. Server over rice.", "sources": [], "ingredients": [{"name": "Pork Chops"}, {"name": "Rice (Basmati)"}, {"name": "Onion"}, {"name": "Carrots", "quantity": "4-5"}, {"name": "Garlic"}, {"name": "Diced Tomatoes"}, {"name": "Tomato Sauce"}, {"name": "Thyme"}, {"name": "Marjoram"}, {"name": "Oregano"}, {"name": "Basil"}]}	2018-12-06 14:50:51.157	2018-12-06 14:50:51.157
4d158b9d-51f4-4d78-8e1a-d126ece1e62d	1	{"title": "Lamb and Bean Soup", "method": "1. Soak beans.\\r\\n2. Brown Lamb Shank in a dutch oven. Remove to plate.\\r\\n3. Cook onions, carrots, and celery until limp and beginning to brown.\\r\\n4. Add lamb and beans to pot.\\r\\n5. Add stock, thyme, and bay leaf. Bring to a boil and then reduce to a low simmer.\\r\\n6. Add garlic.\\r\\n7. Simmer for 1 hour.\\r\\n8. Add chopped collard greens.\\r\\n9. Simmer for about a half hour.\\r\\n10. Add marjoram.\\r\\n11. Simmer for another 20-30 minutes.\\r\\n12. Remove lamb shank. Cut up the meat and add it back to the pot.\\r\\n13. Simmer until collards and beans are tender (0-45 minutes).\\r\\n14. Add a splash of cider vinegar and serve.\\r\\n\\r\\n\\r\\n\\r\\n\\r\\n", "sources": [], "ingredients": [{"name": "Lamb shank"}, {"name": "1 and 1/3  cup orca beans (or cannellini)", "quantity": "1 to"}, {"name": "Snoino"}, {"name": "Carrots, cut into chunks", "quantity": "2-3"}, {"name": "Celery"}, {"name": "Collard Greens"}, {"name": "Garlic"}, {"name": "stock and water", "quantity": "4-5 cups"}, {"name": "Thyme"}, {"name": "Bay leaf"}, {"name": "Marjoram"}]}	2018-12-08 13:43:43.673	2018-12-08 13:43:43.673
80ca25f8-9352-449a-9f0d-e66f249d4835	1	{"title": "Stuffing", "method": "1. Let bread dry for 1-2 hours, then cut into chunks.\\r\\n1. Toast pine nuts.\\r\\n1. Melt butter in dutch oven and cook celery and onion until the onion is translucent.\\r\\n2. Stir in rosemary, sage, thyme, pine nuts, salt, and pepper.\\r\\n3. Add bread and mix until evenly coated.\\r\\n4. Pour broth over all and mix.\\r\\n5. Bake in dutch oven at 350°F for 35-45 minutes. (This can tolerate much higher heat if necessary, like if cooking in same oven as roasting chicken.)\\r\\n\\r\\n", "sources": ["https://www.glutenfreepalate.com/gluten-free-stuffing/"], "ingredients": [{"name": "bread", "quantity": "1 loaf"}, {"name": "butter", "quantity": "1 stick"}, {"name": "onion", "quantity": "1"}, {"name": "celery", "quantity": "3 stalks"}, {"name": "stock", "quantity": "1 1/2 cups"}, {"name": "Rosemary"}, {"name": "Sage"}, {"name": "Thyme"}, {"name": "Pine Nuts"}]}	2018-12-17 14:22:27.273	2018-12-17 14:22:27.273
da88206a-bd44-48c1-9048-667dc74ad3f3	1	{"title": "Soup Dumplings", "method": "Could have used some more flavor (a bit of cheese?).\\r\\n", "sources": [], "ingredients": [{"name": "flour", "quantity": "1 1/3 cup"}, {"name": "baking powder", "quantity": "1 tsp"}, {"name": "salt", "quantity": "1/2 tsp"}, {"name": "milk", "quantity": "2/3 cup"}, {"name": "eggs", "quantity": "2"}]}	2018-12-23 14:13:51.317	2018-12-23 14:13:51.317
648d6df0-d64d-4a56-b2b5-48cda74a2aa6	1	{"title": "Lamb Chops with Garlic and Herbs", "method": "1. Season lamb with salt and pepper\\r\\n2. Combine herbs, garlic, and olive oil\\r\\n3. Rub paste on lamb chops and marinate at room temp 30 minutes\\r\\n4. Heat oil in pan over medium high heat\\r\\n5. Sear chops 2-3 minutes\\r\\n6. Flip chops and cook until 125°F medium rare, or 135°F for medium, about 3-4 minutes\\r\\n7. Let chops rest 10 minutes\\r\\n", "sources": ["https://www.jessicagavin.com/rosemary-and-thyme-lamb-chops/"], "ingredients": [{"name": "Garlic"}, {"name": "Rosemary"}, {"name": "Thyme"}, {"name": "Parsley"}, {"name": "Black Pepper"}, {"name": "Salt"}, {"name": "Olive Oil"}]}	2019-07-20 22:05:40.091	2019-07-20 22:05:40.091
0ce6df64-74ea-4e90-bc42-4ff7af88e154	1	{"title": "Pasta with Ground Duck", "method": "Brown Duck. Drain some rendered fat if excessive. Add diced shallot. Add sliced garlic. Add pepper and tomatoes. Add parsley. Egg can be added to sauce or fried and served on top of pasta. Add some pasta cooking water. Combine with pasta and plenty of parmesan cheese.", "sources": [], "ingredients": [{"name": "Ground Duck"}, {"name": "Cherry or Grape Tomatoes"}, {"name": "Red Bell Pepper or Italian Fryer Pepper"}, {"name": "Parsley"}, {"name": "Shallot"}, {"name": "Garlic"}, {"name": "Eggs"}, {"name": "Parmesan"}]}	2019-09-16 20:29:28.816	2019-09-16 20:29:28.816
2e1f78ae-eb11-450e-bdcf-825f2a5dc41f	1	{"title": "Shrimp Pasta", "method": "1. Melt butter\\r\\n2. Add sliced garlic and pepper flakes. Cook until fragrant\\r\\n3. Add shrimp\\r\\n4. Add spinach\\r\\n5. Add parsley and cheese\\r\\n6. Add cooked pasta\\r\\n7. Squeeze lemon juice over pasta\\r\\n", "sources": ["https://therecipecritic.com/lemon-garlic-parmesan-shrimp-pasta/"], "ingredients": [{"name": "Shrimp", "quantity": "20"}, {"name": "butter", "quantity": "1/2 stick"}, {"name": "Olive Oil"}, {"name": "garlic", "quantity": "4 cloves"}, {"name": "Red pepper flakes"}, {"name": "~4 cups Spinach"}, {"name": "Parsley"}, {"name": "~1/2 cup Asiago or Parmesan Cheese"}, {"name": "Lemon"}]}	2018-12-26 13:49:19.729	2018-12-26 13:49:19.729
75bb96e0-5244-455f-8e3e-fc66fa5809d2	1	{"title": "Lentil Soup", "method": "1. Brown lamb shank and start in slow cooker with red wine and thyme.\\r\\n1. Cook onion, carrots, and turnip.\\r\\n2. Add potatoes.\\r\\n3. Add garlic.\\r\\n4. Add stock, water, and lentils.\\r\\n5. Add lamb shank and bone.\\r\\n6. Remove bone and add chopped spinach.\\r\\n\\r\\n", "sources": [], "ingredients": [{"name": "Lentils"}, {"name": "Stock"}, {"name": "Carrots"}, {"name": "Potatoes"}, {"name": "Turnip"}, {"name": "Onions"}, {"name": "Spinach"}, {"name": "Lamb Shank (optional)"}]}	2019-01-05 19:25:27.237	2019-01-05 19:25:27.237
7b03d158-793c-4bdf-8b62-555de45fde73	1	{"title": "Rice Pilaf with Pork Belly", "method": "Roast pork belly. Cook lentils with thyme and black pepper. Soften carrots and onions. Add rice and minced garlic. Cook with stock, thyme, marjoram, and bay leaf. Chop spinach and add to top of rice near end of cooking. Top with lentils. Combine all in bowl with cubed pork belly and a few dashes of cider vinegar.\\r\\n", "sources": [], "ingredients": [{"name": "Pork Belly"}, {"name": "French Lentils"}, {"name": "Basmati Rice"}, {"name": "Carrots"}, {"name": "Snoino"}, {"name": "Garlic"}, {"name": "Spinach"}, {"name": "Cider Vinegar"}, {"name": "Stock"}]}	2019-01-14 00:00:03.271	2019-01-14 00:00:03.271
24caa43e-822d-4102-9cb1-1ebc5418c129	1	{"title": "Corn Bread", "method": "Grease and flour a pan (I made a double recipe and used a 9-inch\\r\\nsquare pan). Combine the flours, cornmeal, baking powder, baking soda,\\r\\nand salt together in a bowl. Stir in the chopped corn kernels. In\\r\\nanother bowl, whisk the milk, butter, and egg together. Pour the\\r\\nliquid into the flour mixture and add the honey. Gently stir just\\r\\nuntil combined.\\r\\n\\r\\nThe recipe I modified said to bake at 375°F for 20 to 25 minutes, but\\r\\nthe double recipe in a 9-inch square pan took at least 30 minutes if\\r\\nnot more (I can't remember exactly).\\r\\n\\r\\n\\r\\n", "sources": ["https://mail.google.com/mail/u/0/?shva=1#search/corn+bread/126772a59c3f2e9b"], "ingredients": [{"name": "flour", "quantity": "1 cup"}, {"name": "yellow cornmeal", "quantity": "1 cup"}, {"name": "baking powder", "quantity": "2 tsp"}, {"name": "baking soda", "quantity": "1/4 tsp"}, {"name": "salt", "quantity": "1/2 tsp"}, {"name": "chopped fresh (or thawed frozen) corn kernels", "quantity": "1/2 cup"}, {"name": "milk", "quantity": "1 cup"}, {"name": "melted butter", "quantity": "6 Tbs"}, {"name": "egg", "quantity": "1 large"}, {"name": "honey", "quantity": "3 Tbs"}]}	2019-01-27 17:27:39.129	2019-01-27 17:27:39.129
4049adb5-482f-4d02-882a-5d1d19e40bee	1	{"title": "Pan Grilled Steaks", "method": "1. Dry steaks with paper towels.\\r\\n2. Sprinkle steaks with salt and pepper.\\r\\n3. Heat pan for 4 to 5 minutes until it is smoking hot.\\r\\n4. Sprinkle pan with salt and put in the steaks.\\r\\n5. Grill roughly  3 minutes per side", "sources": [], "ingredients": [{"name": "Steaks, about one inch thick"}]}	2019-03-23 22:51:08.29	2019-03-23 22:51:08.29
f143714f-d889-4fd1-a5e6-54bfa71b0e4b	1	{"title": "Rogan Josh Lamb", "method": "1. Brown beef or lamb in olive oil\\r\\n2. Remove meat and brown onion\\r\\n3. Add 2-4 TB spices and some salt\\r\\n4. Stir for a minute\\r\\n5. Add meat.\\r\\n6. Slowly add in 1 cup water and 1/2 cup yogurt\\r\\n7. Cook 1-2 hours over low heat\\r\\n8. Raise heat, reduce sauce until thick\\r\\n\\r\\nGood with Garam Masala green beans and basmati rice.\\r\\n", "sources": ["Penzey's Spice Mix"], "ingredients": [{"name": "Paprika"}, {"name": "Garlic"}, {"name": "Ginger"}, {"name": "Cumin"}, {"name": "Coriander"}, {"name": "Black Pepper"}, {"name": "Cayenne"}, {"name": "Cinnamon"}, {"name": "Cardamom"}, {"name": "Cloves"}, {"name": "Snoino"}, {"name": "Yogurt (1/2 cup)"}]}	2019-03-23 22:55:40.086	2019-03-23 22:55:40.086
9e6f1768-94d5-4423-b7b3-906f3facd080	1	{"title": "Grilled Chicken", "method": "1. Preheat grill\\r\\n1. Flavor chicken\\r\\n2. Put chicken on cool part of grill skin side up\\r\\n3. When most of the fat has rendered (about 20 minutes), turn chicken and put over hotter part of grill\\r\\n4. Chicken is finished 5-10 minutes longer\\r\\n6. Finish chicken directly over the fire", "sources": [], "ingredients": [{"name": "Chicken"}]}	2019-03-23 23:09:46.479	2019-03-23 23:09:46.479
00fc4091-45e8-4eb9-8c04-c401a14c8110	1	{"title": "Lasagna", "method": "1. Make meat sauce\\r\\n1. Heat oven to 400°F\\r\\n1. Cook noodles\\r\\n3. Wilt spinach and combine with ricotta and a bit of meat sauce\\r\\n2. Smear pan with butter or oil\\r\\n3. Put in a layer of noodles\\r\\n4. Over first three layers, spread ricotta, then meat sauce, then mozzarella, then parmesan; perhaps a bit of salt and pepper\\r\\n5. No ricotta on top layer\\r\\n6. Bake for 20-30 minutes, until bubbly\\r\\n7. Let rest for 5 minutes before serving", "sources": [], "ingredients": [{"name": "Meat sauce"}, {"name": "Lasagna noodles"}, {"name": "Ricotta"}, {"name": "Mozzarella"}, {"name": "Parmesan"}, {"name": "Spinach"}]}	2019-03-23 23:15:01.776	2019-03-23 23:15:01.776
dc069be9-8697-4cb4-bb8e-f511e55a15fc	1	{"title": "Five Bean Soup", "method": "Put beans in crock with stock, water, and thyme. Also add ham hock if using. Put on high. Simmer for 3-3.5 hours. Fry bacon (if using) and add to crock (reserve fat) with tomatoes. Sauté mirepoix in bacon fat or olive oil and add to crock. Add garlic and liquid smoke to crock. Cook for another 1-2 hours.\\r\\n", "sources": [], "ingredients": [{"name": "Beans (1/3c Red Beans, 1/3c Navy Beans, 1/3c Black Beans, 1/4c Black-eyed Peas, and 1/4c Split Peas)", "quantity": "11 oz."}, {"name": "Mirepoix"}, {"name": "Tomatoes", "quantity": "1 can"}, {"name": "Bacon (five or so strips) or a Smoked Ham Hock"}, {"name": "Thyme"}, {"name": "Garlic"}, {"name": "Liquid Smoke"}, {"name": "Stock and Water to equal 5 cups"}]}	2019-09-23 16:35:05.443	2019-09-23 16:35:05.443
11b15d58-d605-4fcb-88a9-ed5e121145fe	1	{"title": "Chicken Thighs and Potato Wedges", "method": "Marinate chicken in hot sauce, chipotle, paprika, oregano, lime juice, salt, pepper, and olive oil.\\r\\n\\r\\nCut potatoes into wedges. Coat with olive oil, salt, pepper, and cumin. Roast. Add shredded cheddar for final 2-5 minutes of roasting.\\r\\n\\r\\nPan-fry chicken thighs.\\r\\n\\r\\nServe with veggies.", "sources": [], "ingredients": [{"name": "Boneless, Skinless Chicken Thighs"}, {"name": "Cholula"}, {"name": "Chipotle"}, {"name": "Smoked Paprika"}, {"name": "Oregano"}, {"name": "Lime"}, {"name": "Potatoes"}, {"name": "Cumin"}, {"name": "Cheddar Cheese"}]}	2019-11-20 15:16:20.541	2019-11-20 15:16:20.541
2361b905-fd4c-457c-92fe-f059d7b519a0	1	{"title": "Chicken and Mushroom Casserole", "method": "Combine red wine, soup, and water to make 3 cups of liquid. Add black pepper. Add rice. Pour into baking pan. Add meat. Cover and bake in oven at ~380° for 45 minutes (until rice is done and meat is fully cooked). Add sliced cheese for around the last 10 minutes of cooking.\\r\\n\\r\\n**Sides**\\r\\n\\r\\n* Broccoli\\r\\n", "sources": [], "ingredients": [{"name": "Chicken (or boneless pork chops)"}, {"name": "Cream of Mushroom Soup"}, {"name": "Stock"}, {"name": "Red Wine", "quantity": "1/2 cup"}, {"name": "Long Grain White Rice", "quantity": "1 1/2 cups"}, {"name": "Comte or Gruyere Cheese"}]}	2019-11-20 15:16:37.324	2019-11-20 15:16:37.324
2ad53b86-d781-4397-b982-a21c339c7db4	1	{"title": "Mushroom Ragoût", "method": "#### Dried Mushrooms\\r\\n\\r\\n1. Place dried mushrooms in a bowl or measuring cup.\\r\\n2. Pour on 2 cups boiling water.\\r\\n3. Let soak 30 minutes.\\r\\n4. Place a strainer over a bowl or measuring cup, line with paper towels, and drain the mushrooms.\\r\\n5. Save liquid.\\r\\n6. Squeeze the mushrooms over the strainer.\\r\\n7. Rinse mushrooms and chop.\\r\\n\\r\\n#### Ragoût\\r\\n\\r\\n1. Soften/brown onions.\\r\\n2. Add garlic and cook for about 30 seconds.\\r\\n3. Add fresh mushrooms, rosemary, and thyme.\\r\\n4. Cook mushrooms for about 5-8 minutes.\\r\\n5. Add flour and cook for about 2 minutes more.\\r\\n6. Add prepared dried mushrooms and wine.\\r\\n7. Cook until wine is reduced and glazing the mushrooms.\\r\\n8. Stir in broth from soaking mushrooms.\\r\\n9. Cook until broth is thickened.\\r\\n\\r\\n#### Serving\\r\\n\\r\\nGreat on pasta with parmesan, poached chicken, and bit of chopped spinach.\\r\\n\\r\\n\\r\\n\\r\\n\\r\\n", "sources": ["https://cooking.nytimes.com/recipes/1015828-mushroom-ragout"], "ingredients": [{"name": "dried porcini mushrooms", "quantity": "1 oz"}, {"name": "Snoino"}, {"name": "garlic", "quantity": "2 cloves"}, {"name": "mushrooms, sliced 1/2 inch thick", "quantity": "1 pound"}, {"name": "wild or oyster mushrooms", "quantity": "1 pound"}, {"name": "flour", "quantity": "2 tsp"}, {"name": "Red wine", "quantity": "1/2 cup"}, {"name": "Rosemary"}, {"name": "Thyme"}]}	2019-11-04 23:45:05.597	2019-11-04 23:45:05.597
3c010608-d6b2-4ae7-88df-2cc6f93bf6eb	1	{"title": "Basic Chicken Soup", "method": "1. Sauté onions and celery in oil with salt and pepper.\\r\\n2. Add chicken, crushed garlic, bay leaf, thyme, and 8 cups stock and water.\\r\\n3. Simmer uncovered for 30 minutes.\\r\\n4. Remove breasts and set aside on covered plate.\\r\\n5. Add carrots and bell pepper.\\r\\n6. Simmer for 40 minutes.\\r\\n7. Remove chicken. Discard back, neck, and wings.\\r\\n7. Add kale or other greens\\r\\n8. Let chicken cool some, and then remove from bones and cut into bite-size pieces.\\r\\n9. Add chicken back to soup and simmer a bit to finish until greens are tender.\\r\\n\\r\\n\\r\\n\\r\\n", "sources": ["https://www.marthastewart.com/336138/basic-chicken-soup"], "ingredients": [{"name": "Whole Chicken (3-4 pounds), cut into parts"}, {"name": "Celery"}, {"name": "Carrots"}, {"name": "Snoino"}, {"name": "Garlic"}, {"name": "Bell Pepper"}, {"name": "Kale or Peas"}, {"name": "Stock"}, {"name": "Bay Leaf"}, {"name": "Thyme"}]}	2019-11-10 14:39:15.98	2019-11-10 14:39:15.98
\.


--
-- Data for Name: sharerecipes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sharerecipes (id, fromuserid, touserid) FROM stdin;
1	1	4
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password) FROM stdin;
1	kaaphi	$2a$10$8HngiEOShuhIu3WUODjv1Oe/kd33S9E.XouVBDACjVOsmF22EExwu
4	alissa	$2a$10$mArj7fAl/tayJnUzEB9iT.zi5GB4mwf0SHhrFxeemqv2H9aF.JDf2
\.


--
-- Name: sharerecipes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sharerecipes_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: patches patches_pkey; Type: CONSTRAINT; Schema: _v; Owner: postgres
--

ALTER TABLE ONLY _v.patches
    ADD CONSTRAINT patches_pkey PRIMARY KEY (patch_name);


--
-- Name: recipes recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_pkey PRIMARY KEY (id);


--
-- Name: sharerecipes sharerecipes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sharerecipes
    ADD CONSTRAINT sharerecipes_pkey PRIMARY KEY (id);


--
-- Name: sharerecipes u_uniqueshare; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sharerecipes
    ADD CONSTRAINT u_uniqueshare UNIQUE (fromuserid, touserid);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: recipes_userid_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX recipes_userid_id ON public.recipes USING btree (userid, id);


--
-- Name: sharerecipes_userid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sharerecipes_userid ON public.sharerecipes USING btree (fromuserid, touserid);


--
-- Name: recipes recipes_userid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_userid_fkey FOREIGN KEY (userid) REFERENCES public.users(id);


--
-- Name: sharerecipes sharerecipes_fromuserid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sharerecipes
    ADD CONSTRAINT sharerecipes_fromuserid_fkey FOREIGN KEY (fromuserid) REFERENCES public.users(id);


--
-- Name: sharerecipes sharerecipes_touserid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sharerecipes
    ADD CONSTRAINT sharerecipes_touserid_fkey FOREIGN KEY (touserid) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

